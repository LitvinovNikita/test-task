document.addEventListener('DOMContentLoaded', function() {
    // Initialize current slide index
    let currentIndex = 0;
    
    // Select all elements with the 'slider-item' class
    const slides = document.querySelectorAll('.slider-item');
    
    // Function to show the slide at a given index
    function showSlide(index) {
        // Remove 'active' class from all slides
        slides.forEach(slide => slide.classList.remove('active'));
        // Add 'active' class to the current slide based on the index
        slides[index].classList.add('active');
    }
  
    // Show the first slide upon page load
    showSlide(currentIndex);
  
    // Automatically cycle through slides every 3 seconds
    setInterval(function() {
        // Increment index, loop back to the start if we've reached the end of the slides array
        currentIndex = (currentIndex + 1) % slides.length;
        showSlide(currentIndex);
    }, 3000); // 3-second interval
});