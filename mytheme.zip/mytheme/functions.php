

// Enqueue necessary styles and scripts for the slider functionality.
// This ensures the CSS and JS for the slider are loaded properly.
function enqueue_slider_assets() {
    wp_enqueue_style('slider-style', get_template_directory_uri() . '/style.css');
    wp_enqueue_script('slider-js', get_template_directory_uri() . '/js/slider.js', array(), null, true);
}
add_action('wp_enqueue_scripts', 'enqueue_slider_assets');


// Filter to modify the default number of slots.
// I'm allowing this to be easily adjustable by adding a filter for flexibility.

function modify_slots_count($count) {
    return apply_filters('_slots_per_page', $count);
}

add_filter('_slots_per_page', function ($count) {
    return $count + 1; // Increase slots by 1
});

// Adding customizer settings to let users switch between grid or slider layout for slots.
// Thought this would make the theme more dynamic and user-friendly.
function theme_customizer_settings($wp_customize) {
    $wp_customize->add_section('slots_display_section', array(
        'title' => __('Slots Display', 'mytheme'),
    ));

    // Allowing users to choose between 'Grid' or 'Slider' for displaying slots.
    $wp_customize->add_setting('slots_display_type', array(
        'default' => 'grid',
    ));

    $wp_customize->add_control('slots_display_type', array(
        'label' => __('Display Slots As', 'mytheme'),
        'section' => 'slots_display_section',
        'type' => 'radio',
        'choices' => array(
            'grid' => 'Grid',
            'slider' => 'Slider',
        ),
    ));
}
add_action('customize_register', 'theme_customizer_settings');