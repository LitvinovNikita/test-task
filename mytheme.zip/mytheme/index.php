<div class="slider">
  <!-- Slider Section -->
  <!-- Creating the image slider here. Using the 'active' class for the first slide to show it by default. -->
  <div class="slider">
    <div class="slider-item active">
      <img src="<?php echo get_template_directory_uri(); ?>/images/img1.jpg" alt="Slide 1">
    </div>
    <div class="slider-item">
      <img src="<?php echo get_template_directory_uri(); ?>/images/img2.jpg" alt="Slide 2">
    </div>
    <div class="slider-item">
      <img src="<?php echo get_template_directory_uri(); ?>/images/img3.jpg" alt="Slide 3">
    </div>
  </div>

  <!-- Slots Section -->
  <?php
  // Check the display type selected by the user in the customizer.
  $display_type = get_theme_mod('slots_display_type', 'grid');
  
  // Dynamically generate the container class based on the user's choice of 'grid' or 'slider'.
  if ($display_type == 'grid') {
    echo '<div class="slots-grid">';
  } else {
    echo '<div class="slots-slider">';
  }

  // Allow flexibility by using the filter to modify the number of slots displayed per page.
  // This will return 5 by default, but developers can customize it with the '_slots_per_page' filter.
  $slots_count = apply_filters('_slots_per_page', 5);
  
  // Loop through and generate the slot items.
  for ($i = 1; $i <= $slots_count; $i++) {
    echo '<div class="slot-item">Slot ' . $i . '</div>';
  }

  // Close the dynamically generated container div for grid/slider.
  echo '</div>';
  ?>
</div>

